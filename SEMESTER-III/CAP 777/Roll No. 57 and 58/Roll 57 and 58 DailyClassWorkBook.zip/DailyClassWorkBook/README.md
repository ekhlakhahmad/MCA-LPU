<div align="center">
  <h1>Diary</h1>
  <img src="images/logo.png" height="100" width="100">
</div>

A personal diary web application where users can create notes with text and images and view later on.   

## Features:
* Create a new note
* View previous notes (Search by title, Sort by Title/Date)
* Delete notes

## Developed Using:
* PHP and MySQL
* HTML, CSS
* JavaScript

