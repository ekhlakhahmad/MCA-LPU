<?php
session_start();
$cvData = $_REQUEST['data'];
$cvData="<body><div class='cover '><div class=' ' id='get'>".$cvData."</div></div></body>";

$cvName = $_REQUEST['name'];

$cvStyle=$_REQUEST['style'];

$theme=$_POST["theme"];

$cv = "<html><head id='styleback'>".$cvStyle."</head>".$cvData."</html>";
$time4name = time();
$fileName= $time4name."-".$_SESSION['userId'].".html";
$file  = "allcv/".$fileName;
$handle = fopen($file, 'w') or die('Cannot open file:  '.$file);
fwrite($handle, $cv);
fclose($handle);

$conn = new mysqli('localhost','root','','cv');
if ($cvName == "") {$cvName = "No Name";}
$conn->query("insert into allCv (cvName,cvFileName,userId,theme)values('$cvName','$fileName','$_SESSION[userId]','$theme')");
echo $fileName;
 ?>