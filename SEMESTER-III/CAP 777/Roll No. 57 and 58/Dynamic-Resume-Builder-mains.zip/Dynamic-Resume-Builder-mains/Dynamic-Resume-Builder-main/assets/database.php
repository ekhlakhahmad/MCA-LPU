<?php
$database = "online_resume_maker";
$username = "root";
$pw = "";
$server = "localhost";

$conn = new mysqli($server, $username, $pw, $database);
if ($conn->connect_error) {
    die("Connection failed" . $conn->connect_error);
} else {
    echo "Connection successfully";
}


?>