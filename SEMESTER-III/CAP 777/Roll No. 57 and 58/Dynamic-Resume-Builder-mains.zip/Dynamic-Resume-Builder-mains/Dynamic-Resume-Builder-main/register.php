<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    <title>Online Resume Builder</title>
    <?php require "assets/autoloader.php" ?>
    <style type="text/css" id="#some2">
        <?php include 'css/myStyle.css'; ?>
        <?php include 'css/style.css'; ?>
    </style>
</head>

<body style="background: url('photo/logscreen.jpg');background-size: 100%">
    <div class='fontTreb'
        style="color: white;font-family: Algerian, sans-serif;font-size: 28pt;margin: 22px;text-shadow: 2px 2px 11px black">
        Online Resume Builder
    </div>
    <div class="loginDiv">
        <h1>Register Now!</h1>

        <form method="POST">
           
            <input type="text" name="uname" placeholder="Username" required class="form-control">
            <!-- <input type="email" name="email" required="required" class="form-control" placeholder="Enter Email Address"> -->
            <input type="password" name="pwd" required="required" class="form-control" placeholder="Enter Password"
                pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
            <small>UpperCase, LowerCase, Number/SpecialChar and min 8 Chars</small>
            <input type="password" name="cpwd" required="required" class="form-control" placeholder="Confirm Password">
            <button class="btn btn-success btn-block m1" style="user-select: text;" type="submit" name="login"> <i
                    class="icofont-register"></i> Register</button>
            <p class="text-center pt-3"> Existing User ? <a href="login.php" class='mt-3 text-decoration-none'> Sign In
                </a></p>
            <p class="text-center pt-2 pb-5 "> <a href="index.php" class='mt-3 text-decoration-none'><i
                        class="icofont-long-arrow-left"></i> Back To Home </a></p>
        </form>
    </div>
</body>

</html>
<?php
if (isset($_POST['login'])) {
    $user = $_POST['uname'];
    $pass = md5($_POST['pwd']);  // Hash the password

    $con = new mysqli('localhost', 'root', '', 'online_resume_maker');

    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    $stmt = $con->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $user, $pass);
    
    if ($stmt->execute()) {
        echo "<script>window.location='login.php'</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $con->close();
}


?>