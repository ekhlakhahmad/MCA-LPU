<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
	<title>Online Resume Builder</title>
	<?php require "assets/autoloader.php" ?>
	<style type="text/css" id="some2">
		<?php include 'css/myStyle.css'; ?>
		<?php include 'css/style.css'; ?>
	</style>
</head>

<body style="background: url('photo/logscreen.jpg'); background-size: 100%">
	<div class="fontTreb"
		style="color: white; font-family: Algerian, sans-serif; font-size: 28pt; margin: 22px; text-shadow: 2px 2px 11px black">
		Online Resume Builder
	</div>
	<div class="loginDiv">
		<h1 class="pt-3">Sign In</h1>
		<h3 class="pb-3">Welcome Back !</h3>
		<form method="POST" action="login.php" autocomplete="off">
			<input type="text" name="uname" placeholder="username" required class="form-control">
			<input type="password" name="pwd" placeholder="password" required class="form-control">
			<p class="text-right pt-2 pb-2"> <a href="forget.php" class="mt-3 text-decoration-none"> Forget Password?
				</a></p>
			<button class="btn btn-success btn-block m1" style="user-select: text;" type="submit" name="login"> <i
					class="icofont-login"></i> Sign In</button>
			<p class="text-center pt-3"> New User ? <a href="register.php" class="mt-3 text-decoration-none"> Create An
					Account </a> </p>
		</form>
	</div>
</body>

</html>

<?php

if (isset($_POST['login'])) {
	$user = $_POST['uname'];
	$pass = md5($_POST['pwd']); // Hash the entered password for comparison

	$con = new mysqli('localhost', 'root', '', 'online_resume_maker');

	if ($con->connect_error) {
		die("Connection failed: " . $con->connect_error);
	}

	$stmt = $con->prepare("SELECT id FROM users WHERE username = ? AND password = ?");
	$stmt->bind_param("ss", $user, $pass); // Compare the hashed password

	$stmt->execute();
	$stmt->store_result();

	if ($stmt->num_rows > 0) {
		$stmt->bind_result($userId);
		$stmt->fetch();
		$_SESSION['userId'] = $userId;
		echo "<script>window.location='index.php'</script>";
	} else {
		echo "<div class='alert alert-info mt-3 ml-5 '> Incorrect username or Password </div>";
	}

	$stmt->close();
	$con->close();
}

?>