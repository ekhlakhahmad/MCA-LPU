<?php
session_start();
// $_SESSION['userId'] = '1';
if (!isset($_SESSION['userId'])) {
	header('location:login.php');
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>Online Resume Builder</title>
	<?php require 'assets/function.php'; ?>
	<?php require "assets/autoloader.php" ?>
	<style type="text/css">
		<?php include 'css/myStyle.css'; ?>
		<?php include 'css/style.css'; ?>
	</style>
</head>

<body style="background: url(photo/main.jpg) fixed;">


	<div class="background-image"></div>
	<div class="hub-top">
		<div class="logoname treb"><span>Online Resume Builder </span></div>
	</div>


	<div class="login pull-right " style="margin-right: 44px">
		<div><img src="photo/user.png" class="img-responsive" style="width: 55px;margin:auto;"></div>
		<div class="treb" class="name "><span style="text-align: center;">
				<?php echo userName(); ?>
			</span><br>
			<a href="setting.php"><button class="btn btn-success btn-sm"
					style="padding: 1px 11px;font-size: 8pt">Setting <i class="fa fa-gear fa-fw"></i></button></a>
		</div>

	</div>


	<div class="dashboard treb " style="background-color:transparent;  opacity: inherit;">
		<span class="dbname">Dashboad</span>
		<ul>
			<a href="index.php">
				<li><i class="fa fa-home fa-fw"></i> Home</li>
			</a>
			<a href="newCv.php">
				<li style="background:#739099"><i class="fa fa-edit fa-fw"></i> Build New CV</li>
			</a>
			<a href="savedCv.php">
				<li><i class="fa fa-user-circle fa-fw"></i>Saved CV's</li>
			</a>
			<a href="contactUs.php">
				<li><i class="fa fa-phone fa-fw"></i> Contact Us</li>
			</a>
			<a href="setting.php">
				<li><i class="fa fa-gear fa-fw"></i>Account Setting</li>
			</a>
			<a href="logout.php">
				<li><i class="fa fa-sign-out fa-fw"></i> Logout</li>
			</a>
		</ul>
	</div>
	<div style="margin-left: 18%;padding-top: 122px" class="flex">
		<div class=" well" style="width: 47%; background-color: rgba(0, 0, 0, 0.4);  opacity: inherit;" id="mydiv">
			<div class="well well-sm "
				style="background-color: rgba(0, 0, 0, 0.4);font-family: 'Acme', sans-serif;  opacity: inherit;color: white">
				<h4 class="center">Theme1</h4>
			</div>
			<img src="photo/theme1.png" class="img-responsive"><br><br>
			<a href="theme1.php"><button class="btn btn-primary  btn-block" style="font-family: 'KoHo', sans-serif;">Get
					Start</button></a>
		</div>
		<div class="well well-sm" id="mydiv"
			style="width: 47%;margin-left: 33px;background-color: rgba(0, 0, 0, 0.4);  opacity: inherit">
			<div class="well well-sm "
				style="background-color: rgba(0, 0, 0, 0.4);font-family: 'Acme', sans-serif;  opacity: inherit;color: white">
				<h4 class="center">Theme2</h4>
			</div>
			<!-- <div class="panel-group" id="accordion"> -->
			<img src="photo/theme2.png" class="img-responsive" style="height: 666px"><br><br>
			<a href="theme2.php"><button class="btn btn-primary  btn-block" style="font-family: 'KoHo', sans-serif;">Get
					Start</button></a>

			<!-- </div> -->
		</div>
	</div>
</body>

</html>